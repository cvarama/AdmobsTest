//
//  RewardedVideo.swift
//  AdMobTestApp
//
//  Created by Sivarama Arepu on 02/11/17.
//  Copyright © 2017 Sivarama Arepu. All rights reserved.
//

import UIKit
import GoogleMobileAds

class RewardedVideo: UIViewController, GADRewardBasedVideoAdDelegate {
    
    var rewardedVideoAd: RewardedVideo!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.createAndLoadRewardedVideoAd()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Admobs.RewardedVideo Ad methods
    
    func createAndLoadRewardedVideoAd(){
        let request = GADRequest()
        request.testDevices = [ kGADSimulatorID]
        
        //GADRewardBasedVideoAd.sharedInstance().load(GADRequest(),withAdUnitID: "ca-app-pub-6354828589883920/9053209897")
        GADRewardBasedVideoAd.sharedInstance().load(request,withAdUnitID: "ca-app-pub-6354828589883920/9053209897")
        
        GADRewardBasedVideoAd.sharedInstance().delegate = self
        
    }
    @IBAction func showRewardedVideoAd(_ sender: Any) {
        if GADRewardBasedVideoAd.sharedInstance().isReady == true {
            GADRewardBasedVideoAd.sharedInstance().present(fromRootViewController: self)
        }else{
            print("video Ad is not ready")
        }
    }
}

extension RewardedVideo{
    func rewardBasedVideoAd(_ rewardBasedVideoAd: GADRewardBasedVideoAd,
                            didRewardUserWith reward: GADAdReward) {
        print("Reward received with currency: \(reward.type), amount \(reward.amount).")
    }
    
    func rewardBasedVideoAdDidReceive(_ rewardBasedVideoAd:GADRewardBasedVideoAd) {
        print("Reward based video ad is received.")
    }
    
    func rewardBasedVideoAdDidOpen(_ rewardBasedVideoAd: GADRewardBasedVideoAd) {
        print("Opened reward based video ad.")
    }
    
    func rewardBasedVideoAdDidStartPlaying(_ rewardBasedVideoAd: GADRewardBasedVideoAd) {
        print("Reward based video ad started playing.")
    }
    
    func rewardBasedVideoAdDidClose(_ rewardBasedVideoAd: GADRewardBasedVideoAd) {
        print("Reward based video ad is closed.")
    }
    
    func rewardBasedVideoAdWillLeaveApplication(_ rewardBasedVideoAd: GADRewardBasedVideoAd) {
        print("Reward based video ad will leave application.")
    }
    
    func rewardBasedVideoAd(_ rewardBasedVideoAd: GADRewardBasedVideoAd,
                            didFailToLoadWithError error: Error) {
        print("Reward based video ad failed to load.")
    }
}
